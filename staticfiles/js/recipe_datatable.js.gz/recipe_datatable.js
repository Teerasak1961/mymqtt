$(document).ready(function () {
    // Initialization for the recipe table
    $('#recipe-table').DataTable({
        "paging": true,
        "pageLength": 5,
    });

});
